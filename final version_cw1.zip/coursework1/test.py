import string
a = {'and':{2:[4,6], 8:[3.7,9,0,4],5:[9,8]}, 'or':{2:[5,6], 8:[3.7],5:[4]}}
# print(a['and'][2])
list=[2,5]
re=[]

print(len(a['and']))
print(len(a['and'][8]))

for dc in list:
    for ele in a['and'][dc]:
        if ele+1 in a['or'][dc]:
            re.append(dc)
#print(re)

b = [3,7,8,9,0]
list_new = [1, b[1], b[3]]
#print(list_new)

distance = b[2]
sub_arg1 = b[1:]

# print(distance)
# print(sub_arg1)

# if 3 and 8 in b:
#     print("yes")
# else:
#     print("no")

# a=string.punctuation
# # print(a)
# a1=[]
# def fuc():
#     global a1
#     for ele in b:
#         a1.append(ele)
#
# fuc()
# print(a1[2])

a = ['hi','hello','good','are?']
a1 = [my.replace('?','') for my in a]

print(a1)
